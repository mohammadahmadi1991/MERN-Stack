export interface Auth {
  isReady: boolean;

  username?: string;

  pic?: string;
}
