export interface User {
  username: string;

  pic: string;
}
