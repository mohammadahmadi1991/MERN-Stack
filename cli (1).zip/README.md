# mohsen_javad

## Development server

Run `npm run start:dev` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Build

Run `npm run start:prod` to build the project. The build artifacts will be stored in the `dist/` directory.

## Further help

`--port` & `--host` flags can be used to ship files to production bundled with a server.

To get more help on the project message concerned author.
@@ www.Uryzen317.ir @@
