const bcrypt = require("bcryptjs");

const hashingPasswords = async (password, confirmPassword) => {
  console.log(password, confirmPassword, "paswrods is hjasing password");
  if (password) {
    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash(password, salt);
    const hashConfirmPassword = await bcrypt.hash(confirmPassword, salt);
    console.log(hashPassword, hashPassword, "hash paswords");
    return {
      hashPassword,
      hashConfirmPassword,
    };
  }
};
const comparePassword = async (reqPassword, dbPasswrod) => {
  return await bcrypt.compare(reqPassword, dbPasswrod);
};
module.exports = {
  hashingPasswords,
  comparePassword,
};
