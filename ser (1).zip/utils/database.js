const mongoose = require("mongoose");

const connectToDatabase = async () => {
 try {
    const dbConnect = await mongoose.connect(
      `mongodb+srv://${process.env.DB_USER_NAME}:${process.env.DB_PASSWORD}@cluster0.zutazhf.mongodb.net/O_blog`
    );
    console.log(`data base is connecting ${dbConnect.connection.host}`);
  } catch (err) {
    console.log(err, "data base is cant connect");
    process.exit(1);
  }
};

module.exports = connectToDatabase;
