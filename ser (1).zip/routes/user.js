const userRouter = require("express").Router();
const { register, login, logout } = require("../controller/user");

userRouter.post("/user/register", register);
userRouter.post("/user/login", login);
userRouter.post("/user/logout", logout);
module.exports = userRouter;
