const postRoute = require("express").Router();
const { createPost, posts, postId, search } = require("../controller/post");
// post methods
postRoute.post("/post/create", createPost);
// get methods
postRoute.get("/posts", posts);
postRoute.get("/single/post/:id", postId);
postRoute.get("/search/post", search);

module.exports = postRoute;
