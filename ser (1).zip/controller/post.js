const Post = require("../model/post");
const jwt = require("jsonwebtoken");
const User = require("../model/user");

//* POST -  create post
const createPost = async (req, res) => {
  const { title, content, description, pic } = req.body;
  try {
    const { userToken } = req.cookies;
    const user = await jwt.verify(userToken, process.env.JWT_SECRET, {});
    if (userToken) {
      const post = await Post.create({
        title,
        author: user.id,
        content,
        description,
        pic,
      });
      return res.status(200).json({ message: "post is create", data: post });
    }
  } catch (err) {
    console.log("register user controller have err", err);
    return res
      .status(500)
      .json({ message: "server have a proplem for create post", err: err });
  }
};

//*GET - all posts
const posts = async (req, res) => {
  try {
    const posts = await Post.find()
      .populate("author", "username , pic")
      .sort({ createAt: -1 });
    return res.status(200).json(posts);
  } catch (err) {
    return res
      .status(500)
      .json({ message: "server is proplem cant get all posts", err: err });
  }
};
//*GET - post with id
const postId = async (req, res) => {
  const { id } = req.params;

  try {
    console.log(id, "id in postId");
    const post = await Post.findById(id);
    return res.status(200).json(post);
  } catch (err) {
    console.log(err, "sv is err cn postId");
    return res.status(400).json("sv is err cn postId", err);
  }
};

//* GET - search post with query

const search = async (req, res) => {
  const query = req.query.data;
  console.log("query", query);
  try {
    const user = await User.findOne({
      username: { $regex: query, $options: "i" },
    });
    const search = await Post.find({
      $or: [
        { title: { $regex: query, $options: "i" } },
        { author: user ? user._id : null },
      ],
    }).populate("author", "username");

    console.log(search);
    return res.status(200).json(search);
  } catch (err) {
    console.log("server is error search post cn", err);
    return res.status(400).json("server is error search controller");
  }
};

module.exports = {
  createPost,
  postId,
  posts,
  search,
};
