const User = require("../model/user");
const { comparePassword } = require("../utils/crypt");
const jwt = require("jsonwebtoken");

//* POST - Register
const register = async (req, res) => {
  const errors = {};
  const { username, password, confirmPassword, pic } = req.body;
  try {
    //* yup user validation
    await User.userValidation(req.body);
    //* check user in db
    const userIsExsist = await User.findOne({ username });
    console.log(userIsExsist, "userIsExsist");
    if (userIsExsist) {
      errors.username = "user is exist chose other username";
      return res.status(400).json(errors);
    }
    const user = await User.create({
      username,
      password,
      confirmPassword,
      pic,
    });
    console.log("user is register", user);
    return res
      .status(201)
      .json({ message: "user is register success", data: user });
  } catch (err) {
    console.log(err);
    err?.inner?.forEach((e) => {
      errors[e.path] = e.message;
    });
    return res.status(400).json(errors);
  }
};

//* POST -  login
const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    const passwordIsMatch = await comparePassword(password, user.password);
    console.log(passwordIsMatch, "comparePassword");
    if (passwordIsMatch) {
      const userToken = await jwt.sign(
        {
          id: user._id,
          username: user.username,
          pic: user?.pic,
        },
        process.env.JWT_SECRET,
        {}
      );
      console.log("user token", userToken);
      return res
        .status(200)
        .cookie("userToken", userToken, {
          secure: "false",
          sameSite: "none",
        })
        .json({
          id: user._id,
          username,
          pic: user?.pic,
        });
    } else {
      throw "err";
    }
  } catch (err) {
    console.log("user login cn err", err);
    return res
      .status(400)
      .json({ message: "user or password is worng", err: err });
  }
};

//* POST - logut
const logout = async (req, res) => {
  try {
    return res.cookie("userToken", " ").status(200).json("user is logout");
  } catch (err) {
    console.log("logout controll err", err);
  }
};

module.exports = {
  register,
  login,
  logout,
};
