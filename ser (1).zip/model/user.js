const mongoose = require("mongoose");
const hashingPasswords = require("../utils/crypt");
const userValidation = require("../utils/userValidtion");
const bcrypt = require("bcryptjs");

const userShecma = new mongoose.Schema({
  username: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  confirmPassword: {
    type: String,
    required: true,
  },
  pic: {
    type: String,
    default: "https://i.postimg.cc/PfvxsgPB/woman-2.png",
  },
});

// validation user
userShecma.statics.userValidation = (body) => {
  return userValidation.validate(body, { abortEarly: false });
};

// hash password & confirmPassword

userShecma.pre("save", async function (next) {
  if (!this.isModified) {
    next();
  }
  // hash passwords

  const salt = await bcrypt.genSalt(10);
  const hashPassword = await bcrypt.hash(this.password , salt);
  const hashConfirmPassword = await bcrypt.hash(  this.confirmPassword, salt);
  console.log(hashPassword, hashPassword, "hash paswords");
  // const { hashPassword, hashConfirmPassword } = await hashingPasswords(
  //   this.password,
  //   this.confirmPassword
  // );
  this.password = hashPassword;
  this.confirmPassword = hashConfirmPassword;
});

const User = mongoose.model("user", userShecma);

module.exports = User;
