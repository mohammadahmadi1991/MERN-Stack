const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const connectToDatabase = require("./utils/database");
const app = express();

app.use(bodyParser.json());
app.use(cookieParser());
app.use(
  cors({
    credentials: true,
    origin: "http://localhost:4300",
  })
);
require("dotenv").config({ path: "./config.env" });

//* connect to data base
connectToDatabase();

//* routes
app.use("/", require("./routes/user"));
app.use("/", require("./routes/post"));
//* server is listen
const port = process.env.PORT || 3004;
const server = app.listen(port, () => {
  console.log(`server is runing at http://localhost:${port}`);
});
